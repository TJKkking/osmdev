# openldap-operator

## Description

Proxy charm that exposes operations against an openldap server.
